import React, { useState } from 'react';
import './App.css';

function App() {
  const [pantalla, setPantalla] = useState("inicio");

  const mostrarLogin = () => setPantalla("login");
  const mostrarRegistro = () => setPantalla("registro");
  const volverInicio = () => setPantalla("inicio");

  return (
    <div className="container">
      <header>
        {pantalla === "inicio" && (
          <div className="header-buttons">
            <button className="btn" onClick={mostrarLogin}>Login</button>
            <button className="btn" onClick={mostrarRegistro}>Registrarse</button>
          </div>
        )}
        <h1>
          {pantalla === "login" && "Iniciar Sesión"}
          {pantalla === "registro" && "Registrarse"}
          {pantalla === "inicio" && "Bienvenido a mi Página Web"}
        </h1>
        {pantalla === "inicio" && <p>Hecha con React, HTML y CSS 😄</p>}
      </header>

      <main>
        {pantalla === "login" && (
          <div className="login-form">
            <form>
              <input type="text" placeholder="Usuario o correo" required />
              <input type="password" placeholder="Contraseña" required />
              <button type="submit">Entrar</button>
            </form>
            <p>¿No tienes cuenta? <a href="#" onClick={mostrarRegistro}>Regístrate</a></p>
            <button className="btn volver-btn" onClick={volverInicio}>Volver a la página principal</button>
          </div>
        )}

        {pantalla === "registro" && (
          <div className="login-form">
            <form>
              <input type="text" placeholder="Nombre completo" required />
              <input type="email" placeholder="Correo electrónico" required />
              <input type="password" placeholder="Contraseña" required />
              <button type="submit">Crear cuenta</button>
            </form>
            <p>¿Ya tienes cuenta? <a href="#" onClick={mostrarLogin}>Inicia sesión</a></p>
            <button className="btn volver-btn" onClick={volverInicio}>Volver a la página principal</button>
          </div>
        )}

        {pantalla === "inicio" && (
          <>
            <section>
              <h2>Sobre mí</h2>
              <p>Hola, soy un desarrollador aprendiendo React y creando cosas geniales.</p>
            </section>
            <section>
              <h2>Proyectos</h2>
              <ul>
                <li>Proyecto 1: Página de portafolio</li>
                <li>Proyecto 2: Blog personal</li>
              </ul>
            </section>
          </>
        )}
      </main>

      <footer>
        <p>© 2025 Mi Página Web</p>
      </footer>
    </div>
  );
}

export default App;
